import base64
import hashlib
import json
import logging
import os
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timezone

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError


LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)
S3 = boto3.client("s3", config=Config(signature_version="s3v4"))
MAX_BYTES = 5 * 1024 * 1024
THUMB_MAX_BYTES = 1024 * 1024
URL_TTL = 900  # 署名付きURLの有効期間（秒）。ページ内キャッシュにも同じ値を使う
PAGE_SIZE = 24
MAX_SEARCH_KEYS = 2000
PHOTO_ID = re.compile(r"^\d{8}T\d{12}Z_[0-9a-f]{32}$")
MATERIAL_ID = re.compile(r"^[A-Z][A-Z0-9_-]{0,63}$")
CATEGORIES = {"field", "growth", "work", "issue"}  # 圃場/栽培記録/作業/被害・異常
CLIENT_ID = "mg1q2dnn576jln28m5sja6eaf"
ISSUER = "https://cognito-idp.ap-northeast-1.amazonaws.com/ap-northeast-1_OFiPcQjkC"


class RequestError(Exception):
    def __init__(self, status, message):
        self.status = status
        self.message = message


def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(body, ensure_ascii=False),
    }


def text(data, name, maximum, required=True):
    value = data.get(name, "")
    if not isinstance(value, str) or len(value) > maximum:
        raise RequestError(400, f"{name} が不正です。")
    value = value.strip()
    if required and not value:
        raise RequestError(400, f"{name} を入力してください。")
    return value


def read_json(bucket, key):
    try:
        result = S3.get_object(Bucket=bucket, Key=key)
    except ClientError as error:
        if error.response["Error"]["Code"] in ("NoSuchKey", "404"):
            raise RequestError(404, "写真情報が見つかりません。") from error
        raise
    with result["Body"] as stream:
        return json.loads(stream.read())


def write_json(bucket, key, data):
    S3.put_object(
        Bucket=bucket, Key=key,
        Body=json.dumps(data, ensure_ascii=False).encode("utf-8"),
        ContentType="application/json", CacheControl="no-store",
    )


def valid_date(value, message):
    try:
        if date.fromisoformat(value).isoformat() != value:
            raise ValueError("noncanonical date")
    except ValueError as error:
        raise RequestError(400, message) from error


def _signed_image_url(bucket, key):
    return S3.generate_presigned_url(
        "get_object",
        Params={
            "Bucket": bucket, "Key": key,
            "ResponseContentType": "image/jpeg",
            "ResponseContentDisposition": "inline",
            # 一覧の再描画・ビューアで同じURLを再利用したときに再ダウンロードしない
            "ResponseCacheControl": f"private, max-age={URL_TTL}",
        },
        ExpiresIn=URL_TTL,
    )


def public_photo(bucket, metadata):
    metadata = dict(metadata)
    metadata.pop("uploadedBy", None)
    image_key = metadata.pop("imageKey")
    thumb_key = metadata.pop("thumbKey", None)
    metadata["url"] = _signed_image_url(bucket, image_key)
    if thumb_key:
        metadata["thumbUrl"] = _signed_image_url(bucket, thumb_key)  # 一覧用の軽量サムネイル
    return metadata


def user_groups(claims):
    # API Gateway検証済みの cognito:groups のみ信頼する。値は "[admin family]" 形式で届く。
    return set(str(claims.get("cognito:groups", "")).strip("[]").replace(",", " ").split())


def material_identity(data, require_id=True):
    kind = text(data, "materialType", 20)
    if kind not in ("fertilizer", "pesticide"):
        raise RequestError(400, "資材の種類が不正です。")
    material_id = text(data, "materialId", 64, required=require_id)
    if material_id and not MATERIAL_ID.fullmatch(material_id):
        raise RequestError(400, "資材IDが不正です。")
    return kind, material_id


def material_manifest(bucket, key, kind, material_id):
    try:
        result = S3.get_object(Bucket=bucket, Key=key)
    except ClientError as error:
        if error.response["Error"]["Code"] in ("NoSuchKey", "404"):
            return {"materialType": kind, "materialId": material_id, "images": [], "representative": None}, None
        raise
    with result["Body"] as stream:
        value = json.loads(stream.read())
    if (not isinstance(value, dict) or value.get("materialType") != kind
            or value.get("materialId") != material_id or not isinstance(value.get("images"), list)):
        raise RuntimeError("Invalid material photo manifest")
    return value, result["ETag"]


def save_material_manifest(bucket, key, manifest, revision):
    try:
        S3.put_object(
            Bucket=bucket, Key=key,
            Body=json.dumps(manifest, ensure_ascii=False).encode("utf-8"),
            ContentType="application/json", CacheControl="no-store",
            **({"IfMatch": revision} if revision else {"IfNoneMatch": "*"}),
        )
    except ClientError as error:
        if error.response["Error"]["Code"] in ("PreconditionFailed", "ConditionalRequestConflict", "409", "412"):
            raise RequestError(409, "別の更新があります。再読み込みしてから操作してください。") from error
        raise


def material_photos(bucket, manifest):
    result = []
    for image in manifest["images"]:
        public = public_photo(bucket, image)
        public["materialType"] = manifest["materialType"]
        public["materialId"] = manifest["materialId"]
        public["representative"] = image["id"] == manifest.get("representative")
        result.append(public)
    return result


def material_record_key(base, material_id):
    return base + f"records/{material_id or '_unassigned'}.json"


def material_storage_keys(base, image, photo_id):
    image_key = image.get("imageKey", "")
    match = re.fullmatch(re.escape(base) + r"images/([A-Z][A-Z0-9_-]{0,63}|_unassigned)/" +
                         re.escape(photo_id) + r"\.jpg", image_key)
    if not match:
        raise RuntimeError("Invalid material image key")
    storage_id = match.group(1)
    return (image_key, base + f"thumbs/{storage_id}/{photo_id}.jpg",
            base + f"pending/{storage_id}/{photo_id}.json")


def transfer_material_photo(bucket, base, kind, source_id, target_id, photo_id):
    if source_id == target_id:
        raise RequestError(400, "異なる資材を選択してください。")
    source_key = material_record_key(base, source_id)
    target_key = material_record_key(base, target_id)
    source, source_revision = material_manifest(bucket, source_key, kind, source_id)
    target, target_revision = material_manifest(bucket, target_key, kind, target_id)
    source_image = next((item for item in source["images"] if item["id"] == photo_id), None)
    target_image = next((item for item in target["images"] if item["id"] == photo_id), None)
    transfer = {"from": source_id, "to": target_id}

    if source_image:
        if source_image.get("transfer") not in (None, {**transfer, "role": "source"}):
            raise RequestError(409, "画像の別の紐づけ変更が進行中です。")
        if not source_image.get("transfer"):
            source_image["transfer"] = {**transfer, "role": "source"}
            save_material_manifest(bucket, source_key, source, source_revision)
        image_key, _, pending_key = material_storage_keys(base, source_image, photo_id)
        pending = read_json(bucket, pending_key)
        if pending.get("id") != photo_id or pending.get("imageKey") != image_key or pending.get("deleted"):
            raise RequestError(409, "画像の保存状態を確認できません。")
        if not pending.get("moved"):
            pending["moved"] = True
            write_json(bucket, pending_key, pending)
        if target_image and target_image.get("transfer") != {**transfer, "role": "target"}:
            raise RequestError(409, "移動先に同じ画像が存在します。")
        if not target_image:
            target_image = {**source_image, "transfer": {**transfer, "role": "target"}}
            target["images"].append(target_image)
            save_material_manifest(bucket, target_key, target, target_revision)
        source, source_revision = material_manifest(bucket, source_key, kind, source_id)
        source_image = next((item for item in source["images"] if item["id"] == photo_id), None)
        if source_image:
            if source_image.get("transfer") != {**transfer, "role": "source"}:
                raise RequestError(409, "画像の紐づけ変更が競合しました。")
            source["images"] = [item for item in source["images"] if item["id"] != photo_id]
            if source.get("representative") == photo_id:
                source["representative"] = next(
                    (item["id"] for item in source["images"] if not item.get("transfer")), None)
            save_material_manifest(bucket, source_key, source, source_revision)
    elif not target_image:
        raise RequestError(404, "資材画像が見つかりません。")

    target, target_revision = material_manifest(bucket, target_key, kind, target_id)
    target_image = next((item for item in target["images"] if item["id"] == photo_id), None)
    if not target_image:
        raise RequestError(409, "移動先の画像を確認できません。再試行してください。")
    if target_image.get("transfer") == {**transfer, "role": "target"}:
        del target_image["transfer"]
        if target_id and not target.get("representative"):
            target["representative"] = photo_id
        save_material_manifest(bucket, target_key, target, target_revision)
    elif target_image.get("transfer"):
        raise RequestError(409, "画像の別の紐づけ変更が進行中です。")
    return {"id": photo_id}


def material_request(route, data, claims, bucket, prefix):
    unassigned = data.get("unassigned") in (True, "1")
    kind, material_id = material_identity(data, require_id=route != "GET /photos" and not unassigned)
    if unassigned and material_id:
        raise RequestError(400, "未紐づけと資材IDは同時に指定できません。")
    base = f"{prefix}materials/{kind}/"
    if route == "GET /photos" and not material_id and not unassigned:
        options = {"Bucket": bucket, "Prefix": base + "records/", "MaxKeys": 24}
        cursor = text(data, "cursor", 4096, required=False)
        if cursor:
            options["ContinuationToken"] = cursor
        try:
            listing = S3.list_objects_v2(**options)
        except ClientError as error:
            if cursor and error.response["Error"]["Code"] in ("InvalidArgument", "InvalidToken"):
                raise RequestError(400, "一覧の続きの取得に失敗しました。再読み込みしてください。") from error
            raise
        keys = [item["Key"] for item in listing.get("Contents", [])]
        with ThreadPoolExecutor(max_workers=8) as pool:
            manifests = list(pool.map(lambda key: read_json(bucket, key), keys))
        images = [photo for manifest in manifests for photo in material_photos(bucket, manifest)]
        can_manage = "admin" in user_groups(claims)
        return {"photos": images, "cursor": listing.get("NextContinuationToken"),
                "canManage": can_manage,
                "pendingDeletions": [
                    {"materialId": manifest["materialId"], "id": photo_id}
                    for manifest in manifests for photo_id in manifest.get("pendingDeletions", [])
                ] if can_manage else []}

    record_key = material_record_key(base, material_id)
    if route == "GET /photos":
        manifest, _ = material_manifest(bucket, record_key, kind, material_id)
        return {"photos": material_photos(bucket, manifest),
                "pendingDeletions": manifest.get("pendingDeletions", [])}

    if "admin" not in user_groups(claims):
        raise RequestError(403, "資材画像の登録・変更は管理者のみ可能です。")

    if route == "POST /photos/uploads":
        photo_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ_") + uuid.uuid4().hex
        storage_id = material_id or "_unassigned"
        image_key = base + f"images/{storage_id}/{photo_id}.jpg"
        thumb_key = base + f"thumbs/{storage_id}/{photo_id}.jpg"
        pending_key = base + f"pending/{storage_id}/{photo_id}.json"
        write_json(bucket, pending_key, {"id": photo_id, "imageKey": image_key, "uploadedBy": claims["sub"]})

        def ticket(key, max_bytes):
            return S3.generate_presigned_post(
                Bucket=bucket, Key=key,
                Fields={"Content-Type": "image/jpeg", "Cache-Control": "no-store"},
                Conditions=[{"Content-Type": "image/jpeg"}, {"Cache-Control": "no-store"},
                            ["content-length-range", 1, max_bytes]],
                ExpiresIn=300,
            )
        return {"id": photo_id, "upload": ticket(image_key, MAX_BYTES),
                "thumbUpload": ticket(thumb_key, THUMB_MAX_BYTES)}

    photo_id = text(data, "id", 80)
    if not PHOTO_ID.fullmatch(photo_id):
        raise RequestError(400, "写真IDが不正です。")
    if route == "POST /photos/edit" and data.get("action") == "associate":
        target_id = text(data, "targetMaterialId", 64, required=False)
        if target_id and not MATERIAL_ID.fullmatch(target_id):
            raise RequestError(400, "紐づけ先の資材IDが不正です。")
        return transfer_material_photo(bucket, base, kind, material_id, target_id, photo_id)
    manifest, revision = material_manifest(bucket, record_key, kind, material_id)

    if route == "POST /photos/delete":
        image = next((item for item in manifest["images"] if item["id"] == photo_id), None)
        if image and image.get("transfer"):
            raise RequestError(409, "紐づけ変更を完了してから削除してください。")
        if image:
            image_key, thumb_key, pending_key = material_storage_keys(base, image, photo_id)
        else:
            storage_id = manifest.get("pendingDeletionStorage", {}).get(photo_id) or material_id or "_unassigned"
            image_key, thumb_key, pending_key = material_storage_keys(
                base, {"imageKey": base + f"images/{storage_id}/{photo_id}.jpg"}, photo_id)
        pending = read_json(bucket, pending_key)
        if pending.get("id") != photo_id or pending.get("imageKey") != image_key:
            raise RuntimeError("Invalid material upload metadata")
        images = manifest["images"]
        queued = manifest.get("pendingDeletions", [])
        found = any(image["id"] == photo_id for image in images)
        if not found and photo_id not in queued:
            if pending.get("deleted") is True:
                return {"id": photo_id}
            raise RequestError(404, "資材画像が見つかりません。")
        if found:
            manifest["images"] = [image for image in images if image["id"] != photo_id]
            if manifest.get("representative") == photo_id:
                manifest["representative"] = next(
                    (item["id"] for item in manifest["images"] if not item.get("transfer")), None)
            manifest["pendingDeletions"] = list(dict.fromkeys([*queued, photo_id]))
            manifest.setdefault("pendingDeletionStorage", {})[photo_id] = image_key.split("/")[-2]
            save_material_manifest(bucket, record_key, manifest, revision)
        if not pending.get("deleted"):
            pending["deleted"] = True
            write_json(bucket, pending_key, pending)
        try:
            S3.delete_object(Bucket=bucket, Key=image_key)
            S3.delete_object(Bucket=bucket, Key=thumb_key)
        except ClientError as error:
            LOGGER.exception("Material image cleanup failed")
            raise RequestError(503, "画像は一覧から外れましたが、保存データの削除に失敗しました。削除を再試行してください。") from error
        manifest, revision = material_manifest(bucket, record_key, kind, material_id)
        manifest["pendingDeletions"] = [item for item in manifest.get("pendingDeletions", [])
                                        if item != photo_id]
        save_material_manifest(bucket, record_key, manifest, revision)
        return {"id": photo_id}

    if route == "POST /photos/edit":
        if data.get("action") != "representative":
            raise RequestError(400, "資材画像の操作が不正です。")
        image = next((item for item in manifest["images"] if item["id"] == photo_id), None)
        if not image:
            raise RequestError(404, "資材画像が見つかりません。")
        if image.get("transfer") or not material_id:
            raise RequestError(409, "紐づけ変更を完了してから代表画像を選択してください。")
        manifest["representative"] = photo_id
        save_material_manifest(bucket, record_key, manifest, revision)
        return {"id": photo_id}

    if route == "POST /photos/complete":
        storage_id = material_id or "_unassigned"
        pending_key = base + f"pending/{storage_id}/{photo_id}.json"
        pending = read_json(bucket, pending_key)
        if pending["uploadedBy"] != claims["sub"]:
            raise RequestError(403, "このアップロードを確定する権限がありません。")
        if pending.get("deleted") is True or pending.get("moved") is True or photo_id in manifest.get("pendingDeletions", []):
            raise RequestError(409, "削除または紐づけ変更された画像は登録できません。")
        if any(image["id"] == photo_id for image in manifest["images"]):
            return {"id": photo_id}
        image_key = base + f"images/{storage_id}/{photo_id}.jpg"
        if pending.get("id") != photo_id or pending.get("imageKey") != image_key:
            raise RuntimeError("Invalid material upload metadata")
        try:
            head = S3.head_object(Bucket=bucket, Key=image_key)
        except ClientError as error:
            if error.response["Error"]["Code"] in ("NoSuchKey", "404"):
                raise RequestError(409, "画像のアップロードが完了していません。") from error
            raise
        if head["ContentType"] != "image/jpeg" or not 0 < head["ContentLength"] <= MAX_BYTES:
            raise RequestError(400, "JPEG画像（5MB以下）のみ保存できます。")
        image = S3.get_object(Bucket=bucket, Key=image_key, Range="bytes=0-2")
        with image["Body"] as stream:
            if stream.read() != b"\xff\xd8\xff":
                raise RequestError(400, "JPEG画像ではありません。")
        metadata = {"id": photo_id, "imageKey": image_key}
        thumb_key = base + f"thumbs/{storage_id}/{photo_id}.jpg"
        try:
            thumb = S3.head_object(Bucket=bucket, Key=thumb_key)
            if thumb["ContentType"] == "image/jpeg" and 0 < thumb["ContentLength"] <= THUMB_MAX_BYTES:
                metadata["thumbKey"] = thumb_key
        except ClientError as error:
            if error.response["Error"]["Code"] not in ("NoSuchKey", "404"):
                raise
        manifest["images"].append(metadata)
        if material_id and not manifest.get("representative"):
            manifest["representative"] = photo_id
        save_material_manifest(bucket, record_key, manifest, revision)
        return {"id": photo_id}

    raise RequestError(404, "APIルートが見つかりません。")


def list_date_keys(bucket, prefix, start, end, field=None):
    base = f"{prefix}by-date/"
    if field is not None:
        digest = hashlib.sha256(field.encode("utf-8")).hexdigest()
        base = f"{prefix}by-field-date/{digest}/"
    options = {"Bucket": bucket, "Prefix": base, "StartAfter": f"{base}{start}/"}
    keys = []
    while True:
        listing = S3.list_objects_v2(**options)
        for item in listing.get("Contents", []):
            if item["Key"][len(base):len(base) + 10] > end:
                return keys
            keys.append(item["Key"])
            limit = 100000 if os.environ.get("PHOTO_SEARCH_INDEX_VERSION") == "2" else MAX_SEARCH_KEYS
            if len(keys) > limit:
                raise RequestError(400, "対象の写真が多すぎます。期間を狭めてください。")
        if not listing.get("IsTruncated"):
            return keys
        options["ContinuationToken"] = listing["NextContinuationToken"]


def read_json_or_none(bucket, key):
    try:
        return read_json(bucket, key)
    except RequestError:
        return None


def field_date_key(prefix, metadata):
    digest = hashlib.sha256(metadata["field"].encode("utf-8")).hexdigest()
    return f"{prefix}by-field-date/{digest}/{metadata['takenOn']}/{metadata['id']}.json"


def write_indexes(bucket, prefix, metadata):
    write_json(bucket, field_date_key(prefix, metadata), metadata)
    write_json(bucket, f"{prefix}by-date/{metadata['takenOn']}/{metadata['id']}.json", metadata)


def photo_labels(data):
    """カテゴリと定植紐づけ（いずれも任意）を検証して返す"""
    category = text(data, "category", 20, required=False)
    if category and category not in CATEGORIES:
        raise RequestError(400, "カテゴリが不正です。")
    planting_ref = text(data, "plantingRef", 200, required=False)
    variety = text(data, "variety", 100, required=False)
    plant_date = text(data, "plantDate", 10, required=False)
    if plant_date:
        valid_date(plant_date, "定植日が不正です。")
    if not planting_ref:
        variety = plant_date = ""
    return category, planting_ref, variety, plant_date


def apply_labels(metadata, category, planting_ref, variety, plant_date):
    """メタデータへカテゴリ・定植紐づけを反映する（空なら削除）"""
    for key, value in (("category", category), ("plantingRef", planting_ref),
                       ("variety", variety), ("plantDate", plant_date)):
        if value:
            metadata[key] = value
        else:
            metadata.pop(key, None)
    return metadata


def edit_photo(bucket, prefix, root, data, claims):
    if not {"admin", "family"} & user_groups(claims):
        raise RequestError(403, "写真を編集する権限がありません。")
    photo_id = text(data, "id", 80)
    if not PHOTO_ID.fullmatch(photo_id):
        raise RequestError(400, "写真IDが不正です。")
    taken_on = text(data, "takenOn", 10)
    valid_date(taken_on, "撮影日が不正です。")
    note = text(data, "note", 1000, required=False)
    labels = photo_labels(data)
    original = read_json(bucket, f"{root}records/{photo_id}.json")
    metadata = apply_labels({**original, "takenOn": taken_on, "note": note,
                             "updatedAt": datetime.now(timezone.utc).isoformat()}, *labels)
    # Keep pending metadata consistent so retrying /complete cannot undo an edit.
    write_json(bucket, f"{root}pending/{photo_id}.json", metadata)
    write_json(bucket, f"{root}records/{photo_id}.json", metadata)
    write_indexes(bucket, prefix, metadata)
    if original["takenOn"] != taken_on:
        S3.delete_object(Bucket=bucket, Key=field_date_key(prefix, original))
        S3.delete_object(
            Bucket=bucket, Key=f"{prefix}by-date/{original['takenOn']}/{photo_id}.json")
    return {"id": photo_id, "takenOn": taken_on, "note": note}


def search_photos(bucket, prefix, data, claims):
    start = text(data, "from", 10)
    end = text(data, "to", 10)
    valid_date(start, "開始日が不正です。")
    valid_date(end, "終了日が不正です。")
    if start > end:
        raise RequestError(400, "開始日は終了日以前にしてください。")
    field = text(data, "field", 100, required=False)
    fields = {field} if field else set()
    if "fields" in data:
        try:
            values = json.loads(data["fields"])
        except (ValueError, TypeError) as error:
            raise RequestError(400, "圃場の指定が不正です。") from error
        if not isinstance(values, list):
            raise RequestError(400, "圃場は配列で指定してください。")
        for value in values:
            fields.add(text({"field": value}, "field", 100))
    cursor = text(data, "cursor", 10, required=False)
    if cursor and not cursor.isdigit():
        raise RequestError(400, "一覧の続きの取得に失敗しました。一覧を更新してください。")
    offset = int(cursor or 0)
    # カテゴリ絞り込み（"none"=未分類）。レコードを読まないと判定できないため全件読みにする
    category = text(data, "category", 20, required=False)
    if category and category != "none" and category not in CATEGORIES:
        raise RequestError(400, "カテゴリが不正です。")

    indexed = os.environ.get("PHOTO_SEARCH_INDEX_VERSION") == "2"
    if indexed and fields:
        with ThreadPoolExecutor(max_workers=8) as pool:
            batches = pool.map(lambda name: list_date_keys(bucket, prefix, start, end, name), sorted(fields))
            keys = [key for batch in batches for key in batch]
        keys.sort(key=lambda key: tuple(key.rsplit("/", 2)[-2:]), reverse=True)
    else:
        keys = sorted(list_date_keys(bucket, prefix, start, end), reverse=True)

    def category_ok(record):
        if not category:
            return True
        if category == "none":
            return not record.get("category")
        return record.get("category") == category

    if (fields and not indexed) or category:
        with ThreadPoolExecutor(max_workers=8) as pool:
            records = list(pool.map(lambda key: read_json_or_none(bucket, key), keys))
        matched = [record for record in records
                   if record and (not fields or indexed or record.get("field") in fields)
                   and category_ok(record)]
    else:
        matched = None
    total = len(matched) if matched is not None else len(keys)
    end_index = offset + PAGE_SIZE
    if matched is not None:
        page = matched[offset:end_index]
    else:
        with ThreadPoolExecutor(max_workers=8) as pool:
            page = [r for r in pool.map(lambda key: read_json_or_none(bucket, key), keys[offset:end_index]) if r]
    groups = user_groups(claims)
    photos = []
    for record in page:
        mine = record.get("uploadedBy") == claims["sub"]
        photo = public_photo(bucket, record)
        photo["canDelete"] = mine or bool({"admin", "family"} & groups)
        photo["canEdit"] = bool({"admin", "family"} & groups)
        photos.append(photo)
    return {"photos": photos, "cursor": str(end_index) if end_index < total else None, "total": total}


def delete_photo(bucket, prefix, root, field_key, photo_id, claims):
    record = read_json(bucket, f"{root}records/{photo_id}.json")
    mine = record.get("uploadedBy") == claims["sub"]
    if not mine and not {"admin", "family"} & user_groups(claims):
        raise RequestError(403, "この写真を削除する権限がありません。")
    keys = [
        f"{root}images/{photo_id}.jpg",
        f"{root}records/{photo_id}.json",
        f"{root}pending/{photo_id}.json",
        f"{prefix}by-date/{record['takenOn']}/{photo_id}.json",
        field_date_key(prefix, record),
    ]
    if record.get("thumbKey"):
        keys.append(record["thumbKey"])
    for key in keys:
        S3.delete_object(Bucket=bucket, Key=key)
    top = read_json_or_none(bucket, f"{prefix}tops/{field_key}.json")
    if top and top.get("id") == photo_id:
        S3.delete_object(Bucket=bucket, Key=f"{prefix}tops/{field_key}.json")


def backfill_date_index(bucket, prefix):
    # Lambdaコンソールから {"action": "backfill"} で手動実行する(API経由では到達不可)。
    count = 0
    options = {"Bucket": bucket, "Prefix": f"{prefix}fields/"}
    while True:
        listing = S3.list_objects_v2(**options)
        for item in listing.get("Contents", []):
            if "/records/" not in item["Key"]:
                continue
            metadata = read_json(bucket, item["Key"])
            write_indexes(bucket, prefix, metadata)
            count += 1
        if not listing.get("IsTruncated"):
            return count
        options["ContinuationToken"] = listing["NextContinuationToken"]


def lambda_handler(event, context):
    if event.get("action") == "backfill" and "routeKey" not in event:
        return {"indexed": backfill_date_index(os.environ["PHOTO_BUCKET"], os.environ["PHOTO_PREFIX"])}
    try:
        # Trust only API Gateway's verified claims, never request body/localStorage roles.
        claims = event.get("requestContext", {}).get("authorizer", {}).get("jwt", {}).get("claims", {})
        if (
            claims.get("token_use") != "access"
            or claims.get("client_id") != CLIENT_ID
            or claims.get("iss") != ISSUER
            or "openid" not in claims.get("scope", "").split()
            or not claims.get("sub")
        ):
            raise RequestError(401, "写真用ログインが必要です。")

        bucket = os.environ["PHOTO_BUCKET"]
        prefix = os.environ["PHOTO_PREFIX"]
        if not prefix or prefix.startswith("/") or not prefix.endswith("/"):
            raise RuntimeError("PHOTO_PREFIX must be a nonempty relative prefix ending with /")
        route = event.get("routeKey")
        if route in ("GET /photos", "GET /photos/by-date", "GET /photos/top", "GET /photos/search"):
            data = event.get("queryStringParameters") or {}
        else:
            raw = event.get("body") or "{}"
            if event.get("isBase64Encoded"):
                raw = base64.b64decode(raw, validate=True).decode("utf-8")
            if len(raw) > 16384:
                raise RequestError(400, "リクエストが大きすぎます。")
            try:
                data = json.loads(raw)
            except (ValueError, TypeError) as error:
                raise RequestError(400, "JSONが不正です。") from error
            if not isinstance(data, dict):
                raise RequestError(400, "JSONオブジェクトを指定してください。")

        if "materialType" in data and route in ("GET /photos", "POST /photos/uploads",
                                                 "POST /photos/complete", "POST /photos/edit",
                                                 "POST /photos/delete"):
            return response(200, material_request(route, data, claims, bucket, prefix))

        if route == "GET /photos/by-date":
            day = text(data, "date", 10)
            valid_date(day, "日付が不正です。")
            if data.get("countOnly") == "1":
                options = {"Bucket": bucket, "Prefix": f"{prefix}by-date/{day}/", "MaxKeys": 1000}
                total = 0
                while True:
                    listing = S3.list_objects_v2(**options)
                    total += len(listing.get("Contents", []))
                    if not listing.get("IsTruncated"):
                        return response(200, {"total": total})
                    options["ContinuationToken"] = listing["NextContinuationToken"]
            options = {"Bucket": bucket, "Prefix": f"{prefix}by-date/{day}/", "MaxKeys": 50}
            cursor = text(data, "cursor", 4096, required=False)
            if cursor:
                options["ContinuationToken"] = cursor
            try:
                listing = S3.list_objects_v2(**options)
            except ClientError as error:
                if cursor and error.response["Error"]["Code"] in ("InvalidArgument", "InvalidToken"):
                    raise RequestError(400, "一覧の続きの取得に失敗しました。一覧を更新してください。") from error
                raise
            photos = [public_photo(bucket, read_json(bucket, item["Key"])) for item in listing.get("Contents", [])]
            return response(200, {"photos": photos, "cursor": listing.get("NextContinuationToken")})

        if route == "GET /photos/search":
            return response(200, search_photos(bucket, prefix, data, claims))

        field = text(data, "field", 100)
        field_key = hashlib.sha256(field.encode("utf-8")).hexdigest()
        root = f"{prefix}fields/{field_key}/"

        if route == "GET /photos/top":
            try:
                top = read_json(bucket, f"{prefix}tops/{field_key}.json")
                record = read_json(bucket, f"{root}records/{top['id']}.json")
            except RequestError:
                return response(200, {"photo": None})
            return response(200, {"photo": public_photo(bucket, record)})

        if route == "POST /photos/top":
            if not {"admin", "family"} & user_groups(claims):
                raise RequestError(403, "トップ写真を設定する権限がありません。")
            photo_id = text(data, "id", 80)
            if not PHOTO_ID.fullmatch(photo_id):
                raise RequestError(400, "写真IDが不正です。")
            read_json(bucket, f"{root}records/{photo_id}.json")
            write_json(bucket, f"{prefix}tops/{field_key}.json", {
                "id": photo_id, "field": field, "setBy": claims["sub"],
                "setAt": datetime.now(timezone.utc).isoformat(),
            })
            return response(200, {"id": photo_id})

        if route == "POST /photos/delete":
            photo_id = text(data, "id", 80)
            if not PHOTO_ID.fullmatch(photo_id):
                raise RequestError(400, "写真IDが不正です。")
            delete_photo(bucket, prefix, root, field_key, photo_id, claims)
            return response(200, {"id": photo_id})

        if route == "POST /photos/thumb":
            # 既存写真へのサムネイル後付け（一覧ページの一括生成ボタンが使う）。
            # done なしで保存チケットを発行し、done ありで検証してレコードに反映する。
            if not {"admin", "family"} & user_groups(claims):
                raise RequestError(403, "サムネイルを生成する権限がありません。")
            photo_id = text(data, "id", 80)
            if not PHOTO_ID.fullmatch(photo_id):
                raise RequestError(400, "写真IDが不正です。")
            record = read_json(bucket, f"{root}records/{photo_id}.json")
            thumb_key = f"{root}thumbs/{photo_id}.jpg"
            if not data.get("done"):
                upload = S3.generate_presigned_post(
                    Bucket=bucket, Key=thumb_key,
                    Fields={"Content-Type": "image/jpeg", "Cache-Control": "no-store"},
                    Conditions=[
                        {"Content-Type": "image/jpeg"}, {"Cache-Control": "no-store"},
                        ["content-length-range", 1, THUMB_MAX_BYTES],
                    ],
                    ExpiresIn=300,
                )
                return response(200, {"id": photo_id, "upload": upload})
            try:
                head = S3.head_object(Bucket=bucket, Key=thumb_key)
            except ClientError as error:
                if error.response["Error"]["Code"] in ("NoSuchKey", "404"):
                    raise RequestError(409, "サムネイルのアップロードが完了していません。") from error
                raise
            if head["ContentType"] != "image/jpeg" or not 0 < head["ContentLength"] <= THUMB_MAX_BYTES:
                raise RequestError(400, "サムネイルはJPEG画像（1MB以下）のみ保存できます。")
            metadata = {**record, "thumbKey": thumb_key,
                        "updatedAt": datetime.now(timezone.utc).isoformat()}
            write_json(bucket, f"{root}pending/{photo_id}.json", metadata)
            write_json(bucket, f"{root}records/{photo_id}.json", metadata)
            write_indexes(bucket, prefix, metadata)
            return response(200, {"id": photo_id, "thumb": True})

        if route == "POST /photos/edit":
            return response(200, edit_photo(bucket, prefix, root, data, claims))

        if route == "POST /photos/uploads":
            taken_on = text(data, "takenOn", 10)
            valid_date(taken_on, "撮影日が不正です。")
            note = text(data, "note", 1000, required=False)
            log_id = text(data, "logId", 100, required=False)
            labels = photo_labels(data)
            photo_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ_") + uuid.uuid4().hex
            image_key = f"{root}images/{photo_id}.jpg"
            thumb_key = f"{root}thumbs/{photo_id}.jpg"
            metadata = apply_labels({
                "id": photo_id, "field": field, "takenOn": taken_on, "note": note,
                "uploadedAt": datetime.now(timezone.utc).isoformat(),
                "uploadedBy": claims["sub"], "imageKey": image_key, "thumbKey": thumb_key,
            }, *labels)
            if log_id:
                metadata["logId"] = log_id
            write_json(bucket, f"{root}pending/{photo_id}.json", metadata)

            def presigned_post(key, max_bytes):
                return S3.generate_presigned_post(
                    Bucket=bucket, Key=key,
                    Fields={"Content-Type": "image/jpeg", "Cache-Control": "no-store"},
                    Conditions=[
                        {"Content-Type": "image/jpeg"}, {"Cache-Control": "no-store"},
                        ["content-length-range", 1, max_bytes],
                    ],
                    ExpiresIn=300,
                )
            return response(200, {
                "id": photo_id,
                "upload": presigned_post(image_key, MAX_BYTES),
                "thumbUpload": presigned_post(thumb_key, THUMB_MAX_BYTES),  # 一覧用サムネイル（任意）
            })

        if route == "POST /photos/complete":
            photo_id = text(data, "id", 80)
            if not PHOTO_ID.fullmatch(photo_id):
                raise RequestError(400, "写真IDが不正です。")
            metadata = read_json(bucket, f"{root}pending/{photo_id}.json")
            if metadata["uploadedBy"] != claims["sub"]:
                raise RequestError(403, "このアップロードを確定する権限がありません。")
            image_key = metadata["imageKey"]
            try:
                head = S3.head_object(Bucket=bucket, Key=image_key)
            except ClientError as error:
                if error.response["Error"]["Code"] in ("NoSuchKey", "404"):
                    raise RequestError(409, "画像のアップロードが完了していません。") from error
                raise
            if head["ContentType"] != "image/jpeg" or not 0 < head["ContentLength"] <= MAX_BYTES:
                raise RequestError(400, "JPEG画像（5MB以下）のみ保存できます。")
            image = S3.get_object(Bucket=bucket, Key=image_key, Range="bytes=0-2")
            with image["Body"] as stream:
                if stream.read() != b"\xff\xd8\xff":
                    raise RequestError(400, "JPEG画像ではありません。")
            # サムネイルは任意：正しくアップロードされていなければ本画像へフォールバック
            thumb_key = metadata.get("thumbKey")
            if thumb_key:
                try:
                    thumb = S3.head_object(Bucket=bucket, Key=thumb_key)
                    if thumb["ContentType"] != "image/jpeg" or not 0 < thumb["ContentLength"] <= THUMB_MAX_BYTES:
                        raise RequestError(400, "thumb invalid")
                except (ClientError, RequestError):
                    metadata = {k: v for k, v in metadata.items() if k != "thumbKey"}
            write_json(bucket, f"{root}records/{photo_id}.json", metadata)
            write_indexes(bucket, prefix, metadata)
            return response(200, {"id": photo_id})

        if route == "GET /photos":
            options = {"Bucket": bucket, "Prefix": f"{root}records/", "MaxKeys": 20}
            cursor = text(data, "cursor", 4096, required=False)
            if cursor:
                options["ContinuationToken"] = cursor
            try:
                listing = S3.list_objects_v2(**options)
            except ClientError as error:
                if cursor and error.response["Error"]["Code"] in ("InvalidArgument", "InvalidToken"):
                    raise RequestError(400, "一覧の続きの取得に失敗しました。一覧を更新してください。") from error
                raise
            photos = []
            for item in listing.get("Contents", []):
                photos.append(public_photo(bucket, read_json(bucket, item["Key"])))
            return response(200, {"photos": photos, "cursor": listing.get("NextContinuationToken")})

        raise RequestError(404, "APIルートが見つかりません。")
    except RequestError as error:
        return response(error.status, {"message": error.message})
    except Exception:
        LOGGER.exception("Private photos API failed")
        return response(500, {"message": "写真の処理に失敗しました。管理者にお問い合わせください。"})
